<?php

$host = "172.21.28.26";
$user = "mobycrea";
$password = "lafayette";
$dbname = "mobycrea";

?>
